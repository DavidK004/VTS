<?php
require_once 'vendor/autoload.php';

use Faker\Factory;
use Faker\Provider\sr_Latn_RS\Person as SrPerson;
use Faker\Provider\sr_Latn_RS\Address as SrAddress;
use Faker\Provider\hu_HU\Person as HuPerson;
use Faker\Provider\hu_HU\Address as HuAddress;

$fakerSr = Factory::create('sr_Latn_RS');
$fakerSr->addProvider(new SrPerson($fakerSr));
$fakerSr->addProvider(new SrAddress($fakerSr));

$fakerHu = Factory::create('hu_HU');
$fakerHu->addProvider(new HuPerson($fakerHu));
$fakerHu->addProvider(new HuAddress($fakerHu));

$fakers = [
    'sr' => $fakerSr,
    'hu' => $fakerHu,
];

for ($i = 1; $i <= 1000; $i++) {

    $localeKey = array_rand($fakers);
    $faker = $fakers[$localeKey];

    $firstName = $faker->firstName();
    $lastName = $faker->lastName();
    $street = $faker->streetAddress();
    $city = $faker->city();


    echo "#$i [$localeKey] $firstName $lastName – $street, $city<br>";
}